﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Web;
using System.Net.Mail;
using System.Net.Configuration;
using JXTPortal.Common;
using JXTPortal.Entities;
using JXTPortal;
using System.Text;
using System.Configuration;
using EmailSender;

namespace JXTJobAlerts
{
    class Program
    {
        static void Main(string[] args)
        {
            SitesService ss = new SitesService();
            EmailTemplatesService ets = new EmailTemplatesService();
            JobAlertsService jas = new JobAlertsService();
            GlobalSettingsService gss = new GlobalSettingsService();
            ViewJobSearchService vjss = new ViewJobSearchService();

            using (TList<JXTPortal.Entities.Sites> sites = ss.GetAll())
            {
                if (sites.Count > 0)
                {
                    foreach (JXTPortal.Entities.Sites site in sites)
                    {
                        JXTPortal.Entities.EmailTemplates et = ets.GetBySiteIdEmailCode(site.SiteId, "JOBALERT");
                        JXTPortal.Entities.GlobalSettings gs = gss.GetGlobalSettingBySiteID(site.SiteId);

                        if (et != null)
                        {
                            DataSet jads = jas.GetAllAlertsToRunToday(site.SiteId);
                            foreach (DataRow dr in jads.Tables[0].Rows)
                            {
                                int JobAlertID = Convert.ToInt32(dr["JobAlertID"]);
                                string JobAlertName = dr["JobAlertName"].ToString();
                                string SearchKeywords = dr["SearchKeywords"].ToString();
                                int? RecurrenceType = (dr["RecurrenceType"] == DBNull.Value) ? null : (int?)dr["RecurrenceType"];
                                DateTime? DateNextRun = (dr["DateNextRun"] == DBNull.Value) ? null : (DateTime?)dr["DateNextRun"];
                                int MemberID = Convert.ToInt32(dr["MemberID"]);
                                bool? AlertActive = (dr["AlertActive"] == DBNull.Value) ? null : (bool?)dr["AlertActive"];
                                int? EmailFormat = (dr["EmailFormat"] == DBNull.Value) ? null : (int?)dr["EmailFormat"];

                                int SiteID = Convert.ToInt32(dr["SiteID"]);
                                int CountryId = Convert.ToInt32(dr["CountryId"]);
                                int? LocationID = (dr["LocationID"] == DBNull.Value) ? null : (int?)dr["LocationID"];
                                string AreaIDs = dr["AreaIDs"].ToString();
                                int? ProfessionID = (dr["ProfessionID"] == DBNull.Value) ? null : (int?)dr["ProfessionID"];
                                string SearchRoleIDs = dr["SearchRoleIDs"].ToString();
                                string WorkTypeIDs = dr["WorkTypeIDs"].ToString();
                                string SalaryIDs = dr["SalaryIDs"].ToString();
                                string GeneratedSQL = dr["GeneratedSQL"].ToString();
                                string FirstName = dr["FirstName"].ToString();
                                string Surname = dr["Surname"].ToString();
                                string EmailAddress = dr["EmailAddress"].ToString();//m.EmailAddress
                                int salaryid = 0;
                                int.TryParse(SalaryIDs, out salaryid);

                                int worktypeid = 0;
                                int.TryParse(WorkTypeIDs, out worktypeid);

                                using (DataSet dsJobSearch = vjss.GetBySearchFilterRedefine(
                                                    Utils.CleanKeywords(SearchKeywords),
                                                    site.SiteId, null,
                                                    (salaryid > 0) ? salaryid : (int?)null, (worktypeid > 0) ? worktypeid : (int?)null,
                                                    ProfessionID, SearchRoleIDs,
                                                    CountryId,
                                                    LocationID,
                                                    AreaIDs, gs.DefaultLanguageId))
                                {
                                    int count = 0;

                                    Guid EditValidateID = Guid.Empty;
                                    Guid ViewValidateID = Guid.Empty;
                                    Guid UnsubscribeValidateID = Guid.Empty;

                                    using (JXTPortal.Entities.JobAlerts ja = jas.GetByJobAlertId(JobAlertID))
                                    {
                                        DateTime dt = DateTime.Now;
                                        DateTime nextdaydt = DateTime.Now.AddDays(1);
                                        ja.DateLastRun = dt;
                                        ja.DateNextRun = new DateTime(nextdaydt.Year, nextdaydt.Month, nextdaydt.Day, 0, 0, 0);


                                        if (ja.UnsubscribeValidateId == Guid.Empty || ja.UnsubscribeValidateId == null)
                                        {
                                            UnsubscribeValidateID = Guid.NewGuid();
                                            ja.UnsubscribeValidateId = UnsubscribeValidateID;
                                        }
                                        else
                                        {
                                            UnsubscribeValidateID = (Guid)ja.UnsubscribeValidateId;
                                        }

                                        EditValidateID = Guid.NewGuid();
                                        ViewValidateID = Guid.NewGuid();

                                        ja.EditValidateId = EditValidateID;
                                        ja.ViewValidateId = ViewValidateID;
                                        jas.Update(ja);
                                    }

                                    DataTable dtJobSearch = dsJobSearch.Tables[0];

                                    if (dtJobSearch.Rows.Count > 0)
                                    {
                                        count = int.Parse(dtJobSearch.Compute("Sum(RefineCount)", String.Format("RefineTypeID = {0}", (int)PortalEnums.Search.Redefine.SubClassification)).ToString());
                                        using (VList<ViewJobSearch> viewJobSearch = vjss.GetBySearchFilter(
                                                    Utils.CleanKeywords(SearchKeywords),
                                                    site.SiteId, null,
                                                    (salaryid > 0) ? salaryid : (int?)null, (worktypeid > 0) ? worktypeid : (int?)null,
                                                    ProfessionID, SearchRoleIDs,
                                                    CountryId, LocationID,
                                                    AreaIDs,
                                                    gs.DefaultLanguageId,
                                                    0, Convert.ToInt32(ConfigurationManager.AppSettings["JobAlertResults"])))
                                        {
                                            Message message = new Message();
                                            HybridDictionary colemailfields = new HybridDictionary();
                                            string siteurl = site.SiteUrl;
                                            string jobresults = "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"margin-left:6.0pt\"><tbody>{0}</tbody></table>";
                                            string results = string.Empty;
                                            foreach (ViewJobSearch vjs in viewJobSearch)
                                            {
                                                results += string.Format("<tr>" +
                                                        "<td style=\"padding:3.75pt 3.75pt 3.75pt 3.75pt\">" +
                                                            "<div>" +
                                                                "<div style=\"border:none;border-top:solid #666666 1.0pt;padding:0cm 0cm 0cm 0cm;margin-top:3.75pt;margin-bottom:3.75pt\">" +
                                                                    "<div>" +
                                                                        "<p class=\"MsoNormal\">" +
                                                                            "<span style=\"font-size:9.0pt\">" +
                                                                                "<a href=\"{0}\" target=\"_blank\">" +
                                                                                    "<span style=\"text-decoration:none\">{1}</span>" +
                                                                                "</a> {2}</span>" +
                                                                        "</p>" +
                                                                    "</div>" +
                                                                    "<div>" +
                                                                        "<p class=\"MsoNormal\">" +
                                                                            "<span style=\"font-size:9.0pt\">{3}</span>" +
                                                                            "</p>" +
                                                                    "</div>" +
                                                                    "<p class=\"MsoNormal\">" +
                                                                        "<span style=\"font-size:9.0pt\">{4}<br>" +
                                                                        "{5}" +
                                                                        "</span>" +
                                                                    "</p>" +
                                                                "</div>" +
                                                            "</div>" +
                                                        "</td>" +
                                                    "</tr>", "http://" + site.SiteUrl + Utils.GetJobUrl(vjs.JobId, vjs.JobFriendlyName), vjs.JobName,
                                                    vjs.DatePosted.ToString("dd MMM, yyyy"), vjs.AreaName + ", " + vjs.LocationName, vjs.CompanyName, vjs.Description);
                                            }

                                            string strViewResultsUrl = "http://" + siteurl + "/JobAlertsSwitch.aspx?searchid=" + JobAlertID.ToString() + "&viewValidateID=" + ViewValidateID.ToString();
                                            string strEditUrl = "http://" + siteurl + "/JobAlertsEditSwitch.aspx?searchid=" + JobAlertID.ToString() + "&editValidateID=" + EditValidateID.ToString();
                                            string strUnSubscribeURL = "http://" + siteurl + "/JobAlertsUnsubscribe.aspx?searchid=" + JobAlertID.ToString() + "&unsubscribeValidateID=" + UnsubscribeValidateID.ToString();

                                            jobresults = string.Format(jobresults, results);
                                            colemailfields["FIRSTNAME"] = FirstName;
                                            colemailfields["LASTNAME"] = Surname;
                                            colemailfields["ALERTNAME"] = JobAlertName;
                                            colemailfields["ALERTRESULTCOUNT"] = count.ToString();
                                            colemailfields["VIEWRESULTSLINK"] = strViewResultsUrl;
                                            colemailfields["UNSUBSCRIBELINK"] = strUnSubscribeURL;
                                            colemailfields["ALERTEDITLINK"] = strEditUrl;
                                            colemailfields["JOBRESULTS"] = jobresults;
                                            colemailfields["URLSUFFIX"] = siteurl;

                                            message.Format = (Format)EmailFormat;
                                            message.Body = (message.Format == Format.Html) ? et.EmailBodyHtml : et.EmailBodyText;
                                            message.Cc = et.EmailAddressCc;
                                            message.Fields = colemailfields;
                                            message.From = new MailAddress(et.EmailAddressFrom, et.EmailAddressName);
                                            message.Subject = et.EmailSubject;
                                            message.To = new MailAddress(EmailAddress, FirstName + " " + Surname);

                                            EmailSender().Send(message);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private static SmtpSender EmailSender()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            MailSettingsSectionGroup mailConfiguration = (MailSettingsSectionGroup)config.GetSectionGroup("system.net/mailSettings");

            SmtpSender mailObject = new SmtpSender(mailConfiguration.Smtp.Network.Host);

            mailObject.Port = mailConfiguration.Smtp.Network.Port;
            if (!mailConfiguration.Smtp.Network.DefaultCredentials)
            {
                mailObject.UserName = mailConfiguration.Smtp.Network.UserName;
                mailObject.Password = mailConfiguration.Smtp.Network.Password;
            }

            return mailObject;
        }
    }
}

